from django.apps import AppConfig


class DefactoAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'defacto_app'
